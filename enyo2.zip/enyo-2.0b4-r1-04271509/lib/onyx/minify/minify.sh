#!/bin/sh
../../../enyo/tools/minify.sh package.js -output ../build/onyx
