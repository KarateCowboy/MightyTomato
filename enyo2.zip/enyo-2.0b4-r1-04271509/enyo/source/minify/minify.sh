#!/bin/sh
../../tools/minify.sh package.js -no-alias -output ../../build/enyo
