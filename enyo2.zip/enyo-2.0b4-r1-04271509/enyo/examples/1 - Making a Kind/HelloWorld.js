enyo.kind({
	name: "HelloWorld",
	kind: enyo.Control,
	content: "Hello World from Enyo"
});