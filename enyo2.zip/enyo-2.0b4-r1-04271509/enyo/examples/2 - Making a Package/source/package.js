enyo.depends(
	"HelloWorld.css",
	"HelloWorld.js"
);
