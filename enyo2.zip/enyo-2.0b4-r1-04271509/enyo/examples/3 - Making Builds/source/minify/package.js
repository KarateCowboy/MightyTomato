enyo.depends(
	"../package.js"
);
