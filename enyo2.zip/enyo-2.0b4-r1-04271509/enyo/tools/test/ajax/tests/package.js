enyo.depends(
	"AjaxTest.js"
);
