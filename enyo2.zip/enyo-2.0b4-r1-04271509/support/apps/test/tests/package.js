enyo.depends(
	"langTest.js",
	"KindTest.js",
	"AsyncTest.js",
	"AjaxTest.js"
);
