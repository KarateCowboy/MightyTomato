enyo.depends(
	"$lib/fu",
	"$lib/extra/exampler",
	"source/App.css",
	"source/App.js"
);