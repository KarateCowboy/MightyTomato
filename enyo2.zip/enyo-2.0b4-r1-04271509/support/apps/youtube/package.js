﻿enyo.depends(
	"$lib/fu",
	"$lib/extra/youtube",
	"source/Viewer.js",
	"source/app.css",
	"source/App.js"
);