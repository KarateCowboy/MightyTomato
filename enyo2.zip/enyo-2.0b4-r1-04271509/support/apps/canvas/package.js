﻿enyo.depends(
	"$lib/canvas",
	"App.js"
);
