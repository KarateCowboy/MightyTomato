﻿enyo.depends(
	"$lib/fu",
	"source/Flickr.js",
	"source/FlickrSearch.js",
	"source/Viewer.js",
	"source/app.css",
	"source/App.js"
);